({
    doInit: function (cmp, event, helper) {
        try {
            cmp.set('v.showSpinner', true);
            if (!cmp.get('v._negotiation')) {
                helper.getNegotiation(cmp);
            }
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleSave: function (cmp, event, helper) {
        if (cmp.get('v.listenForSave') === true) {
            helper.update(cmp);
        }
    },
    
    onChange: function (cmp, evt, helper) {
        
    },
    onChkChange: function (cmp, evt, helper) {
        if(cmp.get('v.negotiationObj.Provider_Agreement_No_BB__c')){
        	cmp.set('v.isChkActive', true);       
        }
        else{
            cmp.set('v.isChkActive', false);    
            cmp.set('v.negotiationObj.Provider_Agreement_No_BB_Source__c','');
        }
        
    }
})