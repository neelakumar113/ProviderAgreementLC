({
    doInit: function (cmp, event, helper) {
        try {
            helper.initialize(cmp);
            cmp.set('v._availableGotoCalculator', true);
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleSave: function (cmp, event, helper) {
        if (cmp.get('v.listenForSave') === true) {
            helper.update(cmp);
        }
    },
})