({

    unrender: function () {
        this.superUnrender();

        try {
            // Get the empApi component.
            var empApi = cmp.find("empApi");

            var subscription = cmp.get('v.subscription');
            if (subscription) {
                // Callback function to be passed in the subscribe call.
                var callback = function (message) {}.bind(this);

                // Error handler function that prints the error to the console.
                var errorHandler = function (message) {
                    console.error(err);
                }.bind(this);

                // Register error listener and pass in the error handler function.
                empApi.onError(errorHandler);

                // Unsubscribe from the channel using the sub object.
                empApi.unsubscribe(cmp.get('v.subscription'), callback);
            } else {
                cmp.find("overlayLib").notifyClose();
            }
        } catch (err) {
            console.error(err);
        }
    }
})