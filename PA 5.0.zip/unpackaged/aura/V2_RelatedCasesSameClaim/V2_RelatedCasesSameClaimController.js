({
    doInit: function (cmp, event, helper) {
        try {
            if (!cmp.get('v._relatedCasesSameClaim') || cmp.get('v._relatedCasesSameClaim').length == 0) {
                helper.GetRelatedCasesSameClaim(cmp);
            }
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }

    },
    
})