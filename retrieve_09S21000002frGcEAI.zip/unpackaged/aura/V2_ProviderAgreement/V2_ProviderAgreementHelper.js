({
    getNegotiation: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.GetNegotiationPA");
            action.setParams({
                caseId: cmp.get('v.recordId'),
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        var negotiat = response.getReturnValue();
                        cmp.set("v.negotiationObj", negotiat);
                        if(cmp.get('v.negotiationObj.Provider_Agreement_No_BB__c')){
                            cmp.set('v.isChkActive', true);       
                        }
                         
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    this.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    update: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.UpdateNegotiation");
            action.setParams({
                negotiation: cmp.get('v.negotiationObj')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        cmp.set('v._inEditMode', false);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }

                } else if (state === "ERROR") {
                    hlp.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleWarning: function (title, message) {
        let toastParams = {
            title: title,
            message: "Unknown error", // Default error message
            type: "warning",
            mode: 'sticky'
        };

        if (message) {
            toastParams.message = message;
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },


    handleErrors: function (errors, cmp) {
        // Configure error toast
        let toastParams = {
            mode: 'sticky',
            title: "Error",
            message: "Unknown error", // Default error message
            type: "error",

        };

        if (errors) {
            if (Array.isArray(errors) && errors.length > 0) {
                if (errors[0].message) {
                    toastParams.message = errors[0].message;
                } else if (errors[0].fieldErrors) {
                    toastParams.message = this.objToString(errors[0].fieldErrors);
                } else {
                    toastParams.message = 'Could not execute requested action';
                }
            } else {
                toastParams.message = 'Could not execute requested action';
            }
        } else {
            toastParams.message = 'Could not execute requested action';
        }

        if (cmp) {
            cmp.set('v.showSpinner', false);
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },

    objToString: function (obj) {
        var str = '';
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str += p + '::' + obj[p] + '\n';
            }
        }
        return str;
    },
})