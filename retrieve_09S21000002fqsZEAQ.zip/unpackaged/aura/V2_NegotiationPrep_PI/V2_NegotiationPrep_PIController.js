({
    doInit: function (cmp, event, helper) {
        try {
            helper.initialize(cmp);
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleSave: function (cmp, event, helper) {
        helper.update(cmp);
    },

    handleCompleteCase: function (cmp, event, helper) {
        try {
            helper.moveCaseToComplete(cmp);
        } catch (err) {
            console.error(err);
            helper.handleErrors(err);
        }
    },
})