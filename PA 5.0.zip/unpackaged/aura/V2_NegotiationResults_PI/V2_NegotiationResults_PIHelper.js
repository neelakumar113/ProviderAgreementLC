({
    update: function (cmp) {
        var hlp = this;


        try {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c.UpdateNegotiation");
            action.setParams({
                negotiation: cmp.get('v._negotiation')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        cmp.set('v._inEditMode', false);
                        hlp.processDispositionRules(cmp);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }

                } else if (state === "ERROR") {
                    this.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    initialize: function (cmp) {
        var hlp = this;
        try {
            var _negotiation = cmp.get("v._negotiation");
            if (!_negotiation) {
                this.apex(cmp, 'GetNegotiation', {
                    caseId: cmp.get('v.recordId'),
                }).then(function (result) {
                    cmp.set("v._negotiation", result);
                    hlp.processDispositionRules(cmp);
                    cmp.set('v.initialized', true);

                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            } else {
                hlp.processDispositionRules(cmp);

                cmp.set('v.initialized', true);
            }
        } catch (err) {
            this.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    processGenerateDocShowHideLogic: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.CheckEligibilityForCase");
            action.setParams({
                caseId: cmp.get('v.recordId')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        cmp.set('v._negotiation', response.getReturnValue());
                    } catch (err) {
                        console.error(err);
                        hlp.handleErrors(err.message, cmp);
                    }
                } else if (state === "ERROR") {
                    this.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            console.error(err);
            this.handleErrors(err, cmp);
        }
    },

    setCheckBoxVisibility: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.GetTemplateForCase");
            action.setParams({
                caseId: cmp.get('v.recordId')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        var template = response.getReturnValue();

                        if (template.Case_File_Type__c == 'Confirmation of Agreement') {
                            cmp.set('v.showCOACheckbox', true);
                        } else if (template.Case_File_Type__c == 'Written Agreement') {
                            cmp.set('v.showWACheckbox', true);
                        }
                    } catch (err) {
                        console.error(err);
                        hlp.handleErrors(err.message, cmp);
                    }
                } else if (state === "ERROR") {
                    if (JSON.stringify(response.getError()).includes('MORE THAN 1') ||
                        JSON.stringify(response.getError()).includes('ERROR') ||
                        JSON.stringify(response.getError()).includes('NO MATCH')) {} else {
                        this.handleErrors(response.getError(), cmp);
                    }
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            console.error(err);
            this.handleErrors(err, cmp);
        }
    },


    processDispositionRules: function (cmp) {
        var hlp = this;
        cmp.set('v.showClaimAdjustmentResults', false);
        cmp.set('v.showNewPatientBillResults', false);
        cmp.set('v.showCompleteCase', false);
        cmp.set('v._showCompleteNegotiation', false);

        var dispositionsToshowClaimAdjustmentResults = ['<$300 - Pay to Billed Charges', 'Unsuccessful- Pay to Billed Charges', 'Successful - Pay Less Than Billed', 'Successful - Pay Up to Threshold'];
        var dispositionsToshowNewPatientBillDetails = ['Successful-Orig Allowed-No BB', 'Successful - Lower BB Amount'];

        try {
            var _negotiation = cmp.get('v._negotiation');
            var _caseDetail = cmp.get('v._caseDetail');

            if (_negotiation) {
                cmp.set('v.showClaimAdjustmentResults', (dispositionsToshowClaimAdjustmentResults.includes(_negotiation.Negotiation_Disposition__c)));
                cmp.set('v.showNewPatientBillResults', (dispositionsToshowNewPatientBillDetails.includes(_negotiation.Negotiation_Disposition__c)));

                if (_caseDetail.Milestone__c == 'Negotiation' && _caseDetail.Status == 'In Progress') {
                    if (_negotiation.Negotiation_Disposition__c == 'Reprocessed as INN' ||
                        _negotiation.Negotiation_Disposition__c == 'Final Offer Declined by Provider' ||
                        _negotiation.Negotiation_Disposition__c == 'Unable to Reach' ||
                        _negotiation.Negotiation_Disposition__c == 'Case Opened In Error') {
                        cmp.set('v.showCompleteCase', true);
                        cmp.set('v._showCompleteNegotiation', false)
                    } else if (_negotiation.Negotiation_Disposition__c == 'Successful-Orig Allowed-No BB') {
                        if (_negotiation.Negotiation_Confirmation__c == true) {
                            cmp.set('v.showCompleteCase', true);
                            cmp.set('v._showCompleteNegotiation', false);
                        }
                    } else if (_negotiation.Negotiation_Disposition__c == 'Unsuccessful- Pay to Billed Charges' ||
                        _negotiation.Negotiation_Disposition__c == 'Successful - Pay Less Than Billed' ||
                        _negotiation.Negotiation_Disposition__c == 'Successful - Pay Up to Threshold') {
                        if (_negotiation.Negotiation_Binding_Agreement__c == true) {
                            cmp.set('v.showCompleteCase', false);
                            cmp.set('v._showCompleteNegotiation', true);
                        } else {
                            cmp.set('v.showCompleteCase', true);
                            cmp.set('v._showCompleteNegotiation', false);
                        }
                    }
                }

                hlp.processGenerateDocShowHideLogic(cmp);
                hlp.setCheckBoxVisibility(cmp);
            }
        } catch (err) {
            console.error(err);
            hlp.handleErrors(err, cmp);
        }
    },

    moveCaseToCompletePreCheck: function (cmp) {
        var hlp = this;
        var _negotiation = cmp.get('v._negotiation');
        var proceed = false;

        try {

            if (_negotiation.Negotiation_Disposition__c == 'Unsuccessful- Pay to Billed Charges' ||
                _negotiation.Negotiation_Disposition__c == 'Successful - Pay Less Than Billed' ||
                _negotiation.Negotiation_Disposition__c == 'Successful - Pay Up to Threshold') {

                var modalBody;

                $A.createComponent("c:V2_YesNoOverlay", {
                        yes: cmp.getReference('v.proceed'),
                        header: 'Complete and Close the Case for No Written Agreement',
                        message: 'This action cannot be undone. If you proceed the Case will be closed with a disposition of "No Written Agreement Signature"'
                    },
                    function (content, status, errorMessage) {
                        if (status === "SUCCESS") {
                            modalBody = content;
                            cmp.find('overlayLib').showCustomModal({
                                body: modalBody,
                                showCloseButton: true,
                                cssClass: "slds-modal_small",
                                closeCallback: function (result) {
                                    if (cmp.get('v.proceed') == true) {
                                        hlp.moveCaseToComplete(cmp);
                                    }
                                }

                            })
                        } else {
                            hlp.handleErrors(errorMessage);
                        }
                    });
            } else {
                hlp.moveCaseToComplete(cmp);
            }
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }

    },

    moveCaseToComplete: function (cmp) {
        var hlp = this;
        var _caseDetail = cmp.get('v._caseDetail');

        try {

            cmp.set('v.showSpinner', true);
            var action = cmp.get("c.MoveCaseToMilestone");
            action.setParams({
                cse: cmp.get('v._caseDetail'),
                moveToMilestone: 'Complete'
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        _caseDetail = response.getReturnValue();
                        cmp.set('v._caseDetail', _caseDetail);
                        var appEvent = $A.get("e.c:V2_evtCaseMainTabChanged");
                        appEvent.setParams({
                            "selectedTab": 'Complete'
                        });
                        appEvent.fire();
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    hlp.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    apex: function (cmp, apexAction, params) {
        var p = new Promise($A.getCallback(function (resolve, reject) {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c." + apexAction + "");
            action.setParams(params);
            action.setCallback(this, function (callbackResult) {
                cmp.set('v.showSpinner', false);
                if (callbackResult.getState() == 'SUCCESS') {
                    resolve(callbackResult.getReturnValue());
                } else if (callbackResult.getState() == 'ERROR') {
                    console.log('ERROR', callbackResult.getError());
                    reject(callbackResult.getError());
                }
            });
            $A.enqueueAction(action);
        }));
        return p;
    },

    sendDocumentThroughEmail: function (cmp) {
        var hlp = this;

        try {
            var allowedToSend = false;
            allowedToSend = cmp.get('v._profile').canGenerateDocument;
            var mode = 'Negotiator';
            var modalBody;

            $A.createComponent("c:V2_EmailOverlayWithTemplate", {
                    caseID: cmp.get('v.recordId'),
                    recordHomeMode: false,
                    newMessageMode: true,
                    smartDocMode: true,
                    viewMessageMode: false,
                    replyToMessageMode: false,
                    mode: mode,
                    allowedToSend: allowedToSend,
                    _externalConfigs: cmp.get('v._externalConfigs'),
                    _emailMessages: cmp.getReference('v._emailMessagesNegotiator'),
                    _negotiation: cmp.getReference('v._negotiation')
                },
                function (content, status, errorMessage) {
                    if (status === "SUCCESS") {
                        modalBody = content;
                        cmp.find('overlayLib').showCustomModal({
                            body: modalBody,
                            showCloseButton: false,
                            // cssClass: "mymodal slds-modal_small",
                            closeCallback: function (result) {
                                hlp.processDispositionRules(cmp);
                            }
                        })
                    } else if (status === "INCOMPLETE") {
                        console.log("No response from server or client is offline.")
                    } else if (status === "ERROR") {
                        console.error(errorMessage);
                        this.handleErrors(errorMessage);
                    }
                });

        } catch (err) {
            this.handleErrors(err.message);
            console.error(err);
        }
    },

    viewEmail: function (cmp) {
        try {
            var _negotiation = cmp.get('v._negotiation');
            if (_negotiation.Current_SD_File__r.CEmail_Message__r) {
                var emailMessage = _negotiation.Current_SD_File__r.CEmail_Message__r;

                // var allowedToSend = cmp.get('v._profile').canSendNegotiator;
                var caseID = cmp.get('v.recordId');
                var modalBody;

                $A.createComponent("c:V2_EmailOverlayWithTemplate", {
                        caseID: caseID,
                        emailMessage: emailMessage,
                        recordHomeMode: false,
                        viewMessageMode: true,
                        mode: 'Negotiator',
                        allowedToSend: false,
                        _externalConfigs: cmp.get('v._externalConfigs'),
                        _emailMessages: cmp.getReference("v._emailMessagesNegotiator")
                    },
                    function (content, status, errorMessage) {
                        if (status === "SUCCESS") {
                            modalBody = content;
                            cmp.find('overlayLib').showCustomModal({
                                //header: "Create new Task",
                                body: modalBody,
                                showCloseButton: false,
                                // cssClass: "mymodal slds-modal_small",
                                closeCallback: function (result) {}
                            })
                        } else if (status === "INCOMPLETE") {
                            console.log("No response from server or client is offline.")
                        } else if (status === "ERROR") {
                            this.handleErrors(errorMessage);
                        }
                    });
            }
        } catch (err) {
            this.handleErrors(err.message);
            console.error(err);
        }
    },

    sendDocumentThroughFax: function (cmp) {
        var hlp = this;
        try {
            var modalBody;

            $A.createComponent("c:V2_FaxOverlay", {
                    caseId: cmp.get('v.recordId'),
                    newMessageMode: true,
                    viewMessageMode: false,
                    _externalConfigs: cmp.get('v._externalConfigs'),
                    _faxMessages: cmp.getReference('v._faxMessages'),
                    _negotiation: cmp.getReference('v._negotiation')
                },
                function (content, status, errorMessage) {
                    if (status === "SUCCESS") {
                        modalBody = content;
                        cmp.find('overlayLib').showCustomModal({
                            body: modalBody,
                            showCloseButton: false,
                            closeCallback: function (result) {
                                hlp.processDispositionRules(cmp);
                            }
                        })
                    } else if (status === "INCOMPLETE") {
                        console.log("No response from server or client is offline.")
                    } else if (status === "ERROR") {
                        console.error(errorMessage);
                        this.handleErrors(errorMessage);
                    }
                });

        } catch (err) {
            this.handleErrors(err.message);
            console.error(err);
        }
    },


    viewFax: function (cmp) {
        try {
            var _negotiation = cmp.get('v._negotiation');
            var modalBody;

            $A.createComponent("c:V2_FaxOverlay", {
                    caseId: cmp.get('v.recordId'),
                    newMessageMode: false,
                    viewMessageMode: true,
                    _externalConfigs: cmp.get('v._externalConfigs'),
                    _negotiation: cmp.get('v._negotiation'),
                    cFax: _negotiation.Current_SD_File__r.CFax__r
                },
                function (content, status, errorMessage) {
                    if (status === "SUCCESS") {
                        modalBody = content;
                        cmp.find('overlayLib').showCustomModal({
                            body: modalBody,
                            showCloseButton: false,
                            closeCallback: function (result) {}
                        })
                    } else if (status === "INCOMPLETE") {
                        console.log("No response from server or client is offline.")
                    } else if (status === "ERROR") {
                        console.error(errorMessage);
                        this.handleErrors(errorMessage);
                    }
                });
        } catch (err) {
            this.handleErrors(err.message);
            console.error(err);
        }
    },

    sendDocumentThroughDocuSign: function (cmp) {
        try {
            var appEvent = $A.get("e.c:V2_evtTriggerCreateTask");
            appEvent.setParams({
                "mnuItem": 'DocuSign',
                "sdFile": cmp.get('v._negotiation').Current_SD_File__c
            });
            appEvent.fire();
        } catch (err) {
            this.handleErrors(err.message);
            console.error(err);
        }
    },

    viewDocuSign: function (cmp, event, helper) {
        try {
            var _negotiation = cmp.get('v._negotiation');

            var selTaskType;
            var recordTypeList = cmp.get('v._recordTypesTask');

            recordTypeList.forEach(function (recType) {
                if (recType.DeveloperName == 'DocuSign') {
                    selTaskType = recType;
                }
            });


            var modalBody;
            $A.createComponent("c:V2_TaskOverlay", {
                    newTaskCreated: cmp.getReference('v.newTaskCreated'),
                    CaseID: cmp.get('v.recordId'),
                    TaskID: _negotiation.Current_SD_File__r.DocuSign_Task__c,
                    viewModifyTask: true,
                    recordType: selTaskType,
                    recordTypes: recordTypeList,
                    recordHomeMode: false,
                    _profile: cmp.get('v._profile'),
                    _negotiation: cmp.getReference('v._negotiation'),
                    _trainingMode: cmp.get('v._trainingMode'),
                    _caseDetail: cmp.get('v._caseDetail')
                },
                function (content, status) {
                    if (status === "SUCCESS") {
                        modalBody = content;
                        cmp.find('overlayLib').showCustomModal({
                            //header: "View Task",
                            body: modalBody,
                            showCloseButton: false,
                            cssClass: "mymodal slds-modal_small",
                            closeCallback: function (result) {}
                        })
                    }
                });
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }
    },

    handleWarning: function (title, message) {
        let toastParams = {
            title: title,
            message: "Unknown error", // Default error message
            type: "warning",
            mode: 'sticky'
        };

        if (message) {
            toastParams.message = message;
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },


    handleErrors: function (errors, cmp) {
        // Configure error toast
        let toastParams = {
            mode: 'sticky',
            title: "Error",
            message: "Unknown error", // Default error message
            type: "error",

        };

        if (errors) {
            if (Array.isArray(errors) && errors.length > 0) {
                if (errors[0].message) {
                    toastParams.message = errors[0].message;
                } else if (errors[0].fieldErrors) {
                    toastParams.message = this.objToString(errors[0].fieldErrors);
                } else {
                    toastParams.message = 'Could not execute requested action';
                }
            } else {
                toastParams.message = 'Could not execute requested action';
            }
        } else {
            toastParams.message = 'Could not execute requested action';
        }

        if (cmp) {
            cmp.set('v.showSpinner', false);
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },

    objToString: function (obj) {
        var str = '';
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str += p + '::' + obj[p] + '\n';
            }
        }
        return str;
    }
})