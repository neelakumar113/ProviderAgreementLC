({
    doInit: function (cmp, event, helper) {
        try {
            helper.initialize(cmp);
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleSave: function (cmp, event, helper) {
        helper.update(cmp);
    },

    handleCompleteCase: function (cmp, event, helper) {
        try {
            helper.moveCaseToCompletePreCheck(cmp);
        } catch (err) {
            console.error(err);
            helper.handleErrors(err);
        }
    },

    handleGenerateDocument: function (cmp, event, helper) {
        try {
            var modalBody;
            $A.createComponent("c:V2_SmartDocumentEnvelopeOverlay", {
                    caseId: cmp.get('v.recordId'),
                    _negotiation: cmp.getReference('v._negotiation')
                },
                function (content, status) {
                    if (status === "SUCCESS") {
                        modalBody = content;
                        cmp.find('overlayLib').showCustomModal({
                            body: modalBody,
                            showCloseButton: false,
                            cssClass: "mymodal slds-modal_small",
                            closeCallback: function (result) {
                                // if (cmp.get('v.newTaskCreated') === true) {
                                //     helper.GetOpenTasks(cmp);
                                //     helper.GetCompletedTasks(cmp);
                                // }
                            }
                        })
                    }
                });
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }
    },

    openSmartDocSendItem: function (cmp, event, helper) {
        try {
            var _negotiation = cmp.get('v._negotiation');
            if (_negotiation.Current_SD_File__r.Distribution_Method__c == 'Fax') {
                helper.viewFax(cmp);
            } else if (_negotiation.Current_SD_File__r.Distribution_Method__c == 'EMail') {
                helper.viewEmail(cmp);
            } else if (_negotiation.Current_SD_File__r.Distribution_Method__c == 'DocuSign') {
                helper.viewDocuSign(cmp);
            }

        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleSendDocument: function (cmp, event, helper) {
        var allowedToSend = cmp.get('v._profile').canGenerateDocument;
        var modalBody;
        var _negotiation = cmp.get('v._negotiation');

        try {
            if (!_negotiation || !_negotiation.Current_SD_File__c) {
                helper.handleWarning('Nothing to Send', 'Please Generate a Document to Send.');
            } else {
                if (!allowedToSend) {
                    helper.handleWarning('Permission Denied', 'You cannot execute this function.');
                } else {
                    var action = cmp.get("c.GetDistributionListForSDFile");
                    action.setParams({
                        sdFileId: _negotiation.Current_SD_File__c
                    });

                    action.setCallback(helper, function (response) {
                        cmp.set('v.showSpinner', false);
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            try {
                                var distChannels = response.getReturnValue();

                                if (distChannels && distChannels.length > 0) {
                                    var canFax = false;
                                    var canEmail = false;
                                    var canDocuSign = false;

                                    distChannels.forEach(function (itm) {
                                        if (itm.Channel__c == 'EMail') {
                                            canEmail = true;
                                        } else if (itm.Channel__c == 'Fax') {
                                            canFax = true;
                                        } else if (itm.Channel__c == 'DocuSign') {
                                            canDocuSign = true;
                                        }
                                    });

                                    if (canEmail || canDocuSign || canFax) {
                                        $A.createComponent("c:V2_SmartDocChannelSelection", {
                                                channelSelection: cmp.getReference('v.channelSelection'),
                                                docuSignAvailable: canDocuSign,
                                                emailAvailable: canEmail,
                                                faxAvailable: canFax
                                            },
                                            function (content, status, errorMessage) {
                                                if (status === "SUCCESS") {
                                                    modalBody = content;
                                                    cmp.find('overlayLib').showCustomModal({
                                                        body: modalBody,
                                                        showCloseButton: false,
                                                        cssClass: "slds-modal_small",
                                                        closeCallback: function (result) {
                                                            if (cmp.get('v.channelSelection') == 'EMAIL') {
                                                                helper.sendDocumentThroughEmail(cmp);
                                                            } else if (cmp.get('v.channelSelection') == 'FAX') {
                                                                helper.sendDocumentThroughFax(cmp);
                                                            } else if (cmp.get('v.channelSelection') == 'DOCUSIGN') {
                                                                helper.sendDocumentThroughDocuSign(cmp);
                                                            }
                                                        }
                                                    })
                                                } else {
                                                    helper.handleErrors(errorMessage);
                                                }
                                            });
                                    } else {
                                        helper.handleWarning('No Channel Available', 'No Distribution Channel has been configured for this template.');
                                    }
                                }

                            } catch (err) {
                                console.error(err);
                                helper.handleErrors(err.message, cmp);
                            }
                        } else if (state === "ERROR") {
                            this.handleErrors(response.getError(), cmp);
                        }
                    });
                    cmp.set('v.showSpinner', true);
                    $A.enqueueAction(action);
                }
            }
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }

    },

})