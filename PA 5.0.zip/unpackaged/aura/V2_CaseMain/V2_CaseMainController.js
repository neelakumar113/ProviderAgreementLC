({
    doInit: function (cmp, event, helper) {
        try {
            if (cmp.get('v.initialized') === false) {
                cmp.set('v.showSpinner', true);
                helper.initialize(cmp);
            }
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    handleShowEmailPopOver: function (cmp, event, helper) {
        try {
            cmp.set('v.showEmailPopover', true);
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }
    },

    handleHideEmailPopOver: function (cmp, event, helper) {
        try {
            cmp.set('v.showEmailPopover', false);
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }
    },

    handleHideEmailPopOverAndViewAllEmails: function (cmp, event, helper) {
        try {
            cmp.set('v.showEmailPopover', false);
            helper.selectCommunications(cmp);
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }
    },

 //Added by Praneeth start
        parentComponentEvent : function(cmp, event,helper) { 
        //Get the event message attribute
        var message = event.getParam("message"); 
        if(message === "reload") {
                helper.selectChatter(cmp);
    	}      
    } , // End
    
    handleSetNewEmailCount: function (cmp, event, helper) {
        try {
            helper.setNewEmailCount(cmp);
        } catch (err) {
            consoler.err(err);
            helper.handleErrors(err);
        }
    },

    handleImpactedFieldsRefresh: function (cmp, event, helper) {
        try {
            var updatedFields = event.getParam("updatedFields");
            var _caseDetail;

            if (typeof updatedFields != 'undefined') {
                if (updatedFields.HIPPA_Consent__c) {
                    _caseDetail = cmp.get('v._caseDetail');
                    if (_caseDetail) {
                        _caseDetail.HIPPA_Consent__c = updatedFields.HIPPA_Consent__c;
                        cmp.set('v._caseDetail', _caseDetail);
                    }
                }

                if (updatedFields.Authorization_for_Assistance__c) {
                    _caseDetail = cmp.get('v._caseDetail');

                    if (_caseDetail) {
                        _caseDetail.Authorization_for_Assistance__c = updatedFields.Authorization_for_Assistance__c;
                        cmp.set('v._caseDetail', _caseDetail);
                    }
                }

            }
        } catch (err) {
            helper.handleErrors(err.message);
            console.error(err);
        }
    },

    handleNewTask: function (cmp, event, helper) {
        cmp.set('v._completedTasksForCase', []);
        cmp.set('v._openTasksForCase', []);

    },

    tabChanged: function (cmp, event, helper) {
        var selectedTab = event.getParam("selectedTab");

        if (!selectedTab) {
            selectedTab = event.getSource().getLocalId();
        }

        if (selectedTab) {
            if (selectedTab == 'Case Details') {
                helper.selectCaseDetails(cmp);
            } else if (selectedTab == 'Engagement') {
                helper.selectEngagement(cmp);
            } else if (selectedTab == 'Negotiation Prep') {
                helper.selectNegotiationPrep(cmp);
            } else if (selectedTab == 'Negotiation Results') {
                helper.selectNegotiationResults(cmp);
            } else if (selectedTab == 'Follow Up') {
                helper.selectFollowUp(cmp);
            } else if (selectedTab == 'Complete') {
                helper.selectComplete(cmp);
            } else if (selectedTab == 'Files') {
                helper.selectFiles(cmp);
            } else if (selectedTab == 'Tasks') {
                helper.selectTasks(cmp);
            } else if (selectedTab == 'Comments') {
                helper.selectComments(cmp);
            } else if (selectedTab == 'Communications') {
                helper.selectCommunications(cmp);
            } else if (selectedTab == 'Chatter') {
                helper.selectChatter(cmp);
            }
        }
    },

    refreshNegPrep: function (cmp, event, helper) {
         helper.getNegotiationPrep(cmp);
    },
    refreshEngMember: function (cmp, event, helper) {
        helper.getEngagement(cmp);
   },
   
    handleEdit: function (cmp, event, helper) {
        cmp.set('v._caseDetailOriginal', JSON.parse(JSON.stringify(cmp.get('v._caseDetail'))));
        cmp.set('v._engagementOriginal', JSON.parse(JSON.stringify(cmp.get('v._engagement'))));
        cmp.set('v._patientBillOriginal', JSON.parse(JSON.stringify(cmp.get('v._patientBill'))));
        cmp.set('v._negotiationPrepOriginal', JSON.parse(JSON.stringify(cmp.get('v._negotiationPrep'))));
        cmp.set('v._negotiationOriginal', JSON.parse(JSON.stringify(cmp.get('v._negotiation'))));
        cmp.set('v._followUpOriginal', JSON.parse(JSON.stringify(cmp.get('v._followUp'))));
        cmp.set('v._patientBillExtraOriginal', JSON.parse(JSON.stringify(cmp.get('v._patientBillExtra'))));
        cmp.set('v._priqOriginal', JSON.parse(JSON.stringify(cmp.get('v._priq'))));

    },

    handleCancel: function (cmp, event, helper) {
        cmp.set('v._caseDetail', JSON.parse(JSON.stringify(cmp.get('v._caseDetailOriginal'))));
        cmp.set('v._engagement', JSON.parse(JSON.stringify(cmp.get('v._engagementOriginal'))));
        cmp.set('v._patientBill', JSON.parse(JSON.stringify(cmp.get('v._patientBillOriginal'))));
        cmp.set('v._negotiationPrep', JSON.parse(JSON.stringify(cmp.get('v._negotiationPrepOriginal'))));
        cmp.set('v._negotiation', JSON.parse(JSON.stringify(cmp.get('v._negotiationOriginal'))));
        cmp.set('v._followUp', JSON.parse(JSON.stringify(cmp.get('v._followUpOriginal'))));
        cmp.set('v._patientBillExtra', JSON.parse(JSON.stringify(cmp.get('v._patientBillExtraOriginal'))));
        cmp.set('v._priq', JSON.parse(JSON.stringify(cmp.get('v._priqOriginal'))));

        $A.get("e.c:V2_evtResetValidation").fire();
    },

    handleUpdatedTasksEvent: function (cmp, event, helper) {
        helper.checkForQueuedTasks(cmp);
    }

})