({
    update: function (cmp) {
        var hlp = this;

        try {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c.UpdateNegotiationPrep");
            action.setParams({
                negotiationPrep: cmp.get('v._negotiationPrep')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        cmp.set('v._inEditMode', false);
                        hlp.processButtonRules(cmp);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }

                } else if (state === "ERROR") {
                    if (JSON.stringify(response.getError()).includes('NO PERMISSION FOR DISPOSITION')) {
                        hlp.handleWarning('Restricted Disposition', 'Only an OPS Manager or System Administrator can set this Disposition.');
                        cmp.set('v._negotiationPrep', undefined);
                        hlp.initialize(cmp);
                    } else {
                        this.handleErrors(response.getError(), cmp);
                    }
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    initialize: function (cmp) {
        var hlp = this;
        try {
            var _optionsDisposition = cmp.get("v._optionsDisposition");
            var _negotiationPrep = cmp.get("v._negotiationPrep");

            if (!_optionsDisposition || _optionsDisposition.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Negotiation_Prep__c',
                    field_apiname: 'Disposition__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });

                    cmp.set("v._optionsDisposition", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_negotiationPrep) {
                this.apex(cmp, 'GetNegotiationPrep', {
                    caseId: cmp.get('v.recordId'),
                }).then(function (result) {
                    cmp.set("v._negotiationPrep", result);
                    hlp.processButtonRules(cmp);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            } else {
                hlp.processButtonRules(cmp);
            }

        } catch (err) {
            this.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    processButtonRules: function (cmp) {
        var hlp = this;

        try {
            var _negotiationPrep = cmp.get("v._negotiationPrep");
            var _caseDetail = cmp.get('v._caseDetail');

            cmp.set('v.showCompleteCase', false);

            if (_negotiationPrep) {
                if ((!_negotiationPrep.Disposition__c || _negotiationPrep.Disposition__c == '--') &&
                    _caseDetail.Milestone__c == 'Negotiation' &&
                    _caseDetail.Status == 'In Progress') {
                    cmp.set('v.showCompleteCase', false);
                    cmp.set('v._availableGotoCalculator', true);
                } else {
                    if (cmp.get('v._caseDetail').Can_Click_Negotiation_Results__c === false) {
                        cmp.set('v.showCompleteCase', true);
                    }
                    cmp.set('v._availableGotoCalculator', false);
                }
            }
        } catch (err) {
            console.error(err);
            hlp.handleErrors(err);

        }
    },

    moveCaseToComplete: function (cmp) {
        var hlp = this;
        var _caseDetail = cmp.get('v._caseDetail');

        try {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c.MoveCaseToMilestone");
            action.setParams({
                cse: cmp.get('v._caseDetail'),
                moveToMilestone: 'Complete'
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        _caseDetail = response.getReturnValue();
                        cmp.set('v._caseDetail', _caseDetail);
                        var appEvent = $A.get("e.c:V2_evtCaseMainTabChanged");
                        appEvent.setParams({
                            "selectedTab": 'Complete'
                        });
                        appEvent.fire();
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    hlp.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    apex: function (cmp, apexAction, params) {
        var p = new Promise($A.getCallback(function (resolve, reject) {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c." + apexAction + "");
            action.setParams(params);
            action.setCallback(this, function (callbackResult) {
                cmp.set('v.showSpinner', false);
                if (callbackResult.getState() == 'SUCCESS') {
                    resolve(callbackResult.getReturnValue());
                } else if (callbackResult.getState() == 'ERROR') {
                    console.log('ERROR', callbackResult.getError());
                    reject(callbackResult.getError());
                }
            });
            $A.enqueueAction(action);
        }));
        return p;
    },

    handleWarning: function (title, message) {
        let toastParams = {
            title: title,
            message: "Unknown error", // Default error message
            type: "warning",
            mode: 'sticky'
        };

        if (message) {
            toastParams.message = message;
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },


    handleErrors: function (errors, cmp) {
        // Configure error toast
        let toastParams = {
            mode: 'sticky',
            title: "Error",
            message: "Unknown error", // Default error message
            type: "error",

        };

        if (errors) {
            if (Array.isArray(errors) && errors.length > 0) {
                if (errors[0].message) {
                    toastParams.message = errors[0].message;
                } else if (errors[0].fieldErrors) {
                    toastParams.message = this.objToString(errors[0].fieldErrors);
                } else {
                    toastParams.message = 'Could not execute requested action';
                }
            } else {
                toastParams.message = 'Could not execute requested action';
            }
        } else {
            toastParams.message = 'Could not execute requested action';
        }

        if (cmp) {
            cmp.set('v.showSpinner', false);
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },

    objToString: function (obj) {
        var str = '';
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str += p + '::' + obj[p] + '\n';
            }
        }
        return str;
    }
})