({
    update: function (cmp) {
        var hlp = this;

        try {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c.UpdateEngagement");
            action.setParams({
                eng: cmp.get('v._engagement')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        cmp.set('v._inEditMode', false);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }

                } else if (state === "ERROR") {
                    this.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    initialize: function (cmp) {
        var hlp = this;
        try {


            var _optionsState = cmp.get("v._optionsState");
            var _optionsYesNo = cmp.get("v._optionsYesNo");
            var _optionsDisposition = cmp.get("v._optionsDisposition");
            var _optionsProviderPosition = cmp.get('v._optionsProviderPosition');
            var _optionsBillStatus = cmp.get('v._optionsBillStatus');
            var _optionsOnetoTen = cmp.get('v._optionsOnetoTen');
            var _optionsProviderSelection = cmp.get('v._optionsProviderSelection');

            var _engagement = cmp.get("v._engagement");

            if (!_optionsState || _optionsState.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    'objectName': 'Enrolee__c',
                    'field_apiname': 'State__c',
                    'nullRequired': false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });
                    cmp.set("v._optionsState", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_optionsYesNo || _optionsYesNo.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Engagement__c',
                    field_apiname: 'Member_Agrees_to_Use_Naviguard__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });

                    cmp.set("v._optionsYesNo", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_optionsDisposition || _optionsDisposition.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Engagement__c',
                    field_apiname: 'Disposition__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        if (f != 'Case Opened In Error' &&
                            f != 'Provider Declined to Engage') {
                            options.push({
                                'label': f,
                                'value': f
                            });
                        }
                    });

                    cmp.set("v._optionsDisposition", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_optionsProviderPosition || _optionsProviderPosition.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Engagement__c',
                    field_apiname: 'Provider_Position__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });

                    cmp.set("v._optionsProviderPosition", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_optionsBillStatus || _optionsBillStatus.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Engagement__c',
                    field_apiname: 'Billing_Status__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });

                    cmp.set("v._optionsBillStatus", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_optionsOnetoTen || _optionsOnetoTen.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Engagement__c',
                    field_apiname: 'Confidence_Question_1_1_to_10__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });

                    cmp.set("v._optionsOnetoTen", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_optionsProviderSelection || _optionsProviderSelection.length == 0) {
                this.apex(cmp, 'getPicklistvalues', {
                    objectName: 'Engagement__c',
                    field_apiname: 'How_was_the_Provider_selected__c',
                    nullRequired: false
                }).then(function (result) {
                    var options = [];

                    result.forEach(function (f) {
                        options.push({
                            'label': f,
                            'value': f
                        });
                    });

                    cmp.set("v._optionsProviderSelection", options);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }

            if (!_engagement) {
                this.apex(cmp, 'GetEngagement', {
                    caseId: cmp.get('v.recordId'),
                }).then(function (result) {
                    cmp.set("v._engagement", result);
                }).catch(function (err) {
                    hlp.handleErrors(err.message, cmp);
                    console.error(err);
                });
            }
        } catch (err) {
            this.handleErrors(err.message, cmp);
            console.error(err);
        }
    },



    apex: function (cmp, apexAction, params) {
        var p = new Promise($A.getCallback(function (resolve, reject) {
            cmp.set('v.showSpinner', true);
            var action = cmp.get("c." + apexAction + "");
            action.setParams(params);
            action.setCallback(this, function (callbackResult) {
                cmp.set('v.showSpinner', false);
                if (callbackResult.getState() == 'SUCCESS') {
                    resolve(callbackResult.getReturnValue());
                } else if (callbackResult.getState() == 'ERROR') {
                    console.log('ERROR', callbackResult.getError());
                    reject(callbackResult.getError());
                }
            });
            $A.enqueueAction(action);
        }));
        return p;
    },

    handleWarning: function (title, message) {
        let toastParams = {
            title: title,
            message: "Unknown error", // Default error message
            type: "warning",
            mode: 'sticky'
        };

        if (message) {
            toastParams.message = message;
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },


    handleErrors: function (errors, cmp) {
        // Configure error toast
        let toastParams = {
            mode: 'sticky',
            title: "Error",
            message: "Unknown error", // Default error message
            type: "error",

        };

        if (errors) {
            if (Array.isArray(errors) && errors.length > 0) {
                if (errors[0].message) {
                    toastParams.message = errors[0].message;
                } else if (errors[0].fieldErrors) {
                    toastParams.message = this.objToString(errors[0].fieldErrors);
                } else {
                    toastParams.message = 'Could not execute requested action';
                }
            } else {
                toastParams.message = 'Could not execute requested action';
            }
        } else {
            toastParams.message = 'Could not execute requested action';
        }

        if (cmp) {
            cmp.set('v.showSpinner', false);
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },

    objToString: function (obj) {
        var str = '';
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str += p + '::' + obj[p] + '\n';
            }
        }
        return str;
    }
})