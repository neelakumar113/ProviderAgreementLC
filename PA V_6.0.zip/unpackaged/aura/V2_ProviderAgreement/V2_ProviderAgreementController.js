({
    doInit: function (cmp, event, helper) {
        try {
            if (!cmp.get('v._negotiation')) {
                cmp.set('v.showSpinner', true);
                helper.getNegotiation(cmp);
            }
            if(cmp.get('v._negotiation.Provider_Agreement_No_BB__c')){
                cmp.set('v.isChkActive', true);                   
            }
        } catch (err) {
            helper.handleErrors(err.message, cmp);
            console.error(err);
        }
    },
    handleSave: function (cmp, event, helper) {
        if (cmp.get('v.listenForSave') === true) {
            helper.update(cmp);
        }
    },
    
    onChange: function (cmp, evt, helper) {
        if(cmp.find('select').get('v.value') == 'Select an Option'){
            cmp.set('v._negotiation.Provider_Agreement_No_BB_Source__c','');  
        }
        cmp.set('v.showSpinner', true);
        helper.update(cmp);
    },
    onChkChange: function (cmp, event, helper) {
        
        if(cmp.get('v._negotiation.Provider_Agreement_No_BB__c')){
            cmp.set('v.isChkActive', true);                   
        }
        else{
            cmp.set('v.isChkActive', false);    
            cmp.set('v._negotiation.Provider_Agreement_No_BB_Source__c','');
            cmp.set('v.showSpinner', true);
            helper.update(cmp);
        }
        
    }
})