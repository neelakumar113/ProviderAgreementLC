({
    initialize: function (cmp) {
        var hlp = this;

        try {
            //---------------------------ACTION 1 START---------------------------------
            var action1 = cmp.get("c.GetRecordTypesForObject");
            action1.setParams({
                objectName: 'Task'
            })
            action1.setCallback(hlp, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    cmp.set("v._recordTypesTask", response.getReturnValue());

                    //---------------------------ACTION 2 START---------------------------------
                    var action2 = cmp.get("c.GetMultiClaimURL");
                    action2.setParams({
                        caseId: cmp.get('v.recordId')
                    })
                    action2.setCallback(hlp, function (response2) {
                        var state = response2.getState();
                        if (state === "SUCCESS") {
                            cmp.set("v._multiClaimURL", response2.getReturnValue());

                            //---------------------------ACTION 3 START---------------------------------
                            var action3 = cmp.get("c.GetNegotiationURL");
                            action3.setParams({
                                caseId: cmp.get('v.recordId')
                            })
                            action3.setCallback(hlp, function (response3) {
                                var state = response3.getState();
                                if (state === "SUCCESS") {
                                    cmp.set("v._negotiationURL", response3.getReturnValue());
                                    //---------------------------ACTION 3B START---------------------------------
                                    var action3B = cmp.get("c.GetNegotiationURLReadOnly");
                                    action3B.setParams({
                                        caseId: cmp.get('v.recordId')
                                    })
                                    action3B.setCallback(hlp, function (response3B) {
                                        var state = response3B.getState();
                                        if (state === "SUCCESS") {
                                            cmp.set("v._negotiationURLReadOnly", response3B.getReturnValue());
                                            //---------------------------ACTION 4 START---------------------------------
                                            var action4 = cmp.get("c.GetCaseDetail");
                                            action4.setParams({
                                                caseId: cmp.get('v.recordId')
                                            })
                                            action4.setCallback(hlp, function (response4) {
                                                var state = response4.getState();
                                                if (state === "SUCCESS") {
                                                    var caseDetail = response4.getReturnValue();
                                                    cmp.set("v._caseDetail", caseDetail);

                                                    //---------------------------ACTION 5 START---------------------------------
                                                    var action5 = cmp.get("c.GetUserProfile");
                                                    action5.setCallback(hlp, function (response5) {
                                                        var state = response5.getState();
                                                        if (state === "SUCCESS") {
                                                            var result = response5.getReturnValue();
                                                            var canSendAdvisor = false;
                                                            var canSendNegotiator = false;
                                                            var canGenerateDocument = false;
                                                            var canGenerateDocumentFollowUp = false;

                                                            if (result.Name == 'Advisor User') {
                                                                canSendAdvisor = true;
                                                                canGenerateDocumentFollowUp = true;
                                                                canGenerateDocument = false;
                                                            } else if (result.Name == 'Negotiator User' || result.Name == 'Liaison Specialist User') {
                                                                canSendNegotiator = true;
                                                                canGenerateDocument = true;
                                                                canGenerateDocumentFollowUp = false;
                                                            } else if (result.Name == 'OPS Manager' ||
                                                                result.Name == 'System Administrator') {
                                                                canSendAdvisor = true;
                                                                canSendNegotiator = true;
                                                                canGenerateDocument = true;
                                                                canGenerateDocumentFollowUp = true;

                                                            }
                                                            result.canSendAdvisor = canSendAdvisor;
                                                            result.canSendNegotiator = canSendNegotiator;
                                                            result.canGenerateDocument = canGenerateDocument;
                                                            result.canGenerateDocumentFollowUp = canGenerateDocumentFollowUp;
                                                            //result.allowedToSend = canSend;
                                                            cmp.set('v._profile', result);


                                                            //---------------------------ACTION 6 START---------------------------------
                                                            var action6 = cmp.get("c.GetExternalConfigs");
                                                            action6.setCallback(this, function (response6) {
                                                                var state = response6.getState();
                                                                if (state === "SUCCESS") {
                                                                    cmp.set('v._externalConfigs', response6.getReturnValue());
                                                                    hlp.setTrainingModeIfNeeded(cmp);
                                                                    //---------------------------ACTION 7 START---------------------------------
                                                                    var action7 = cmp.get("c.GetEmailSummaryByCaseID");
                                                                    action7.setParams({
                                                                        caseID: cmp.get('v.recordId'),
                                                                        mode: 'Advisor'
                                                                    });
                                                                    action7.setCallback(hlp, function (response7) {
                                                                        var state = response7.getState();
                                                                        if (state === "SUCCESS") {
                                                                            try {
                                                                                var emailMessages = response7.getReturnValue();
                                                                                cmp.set("v._emailMessagesAdvisor", emailMessages);
                                                                                hlp.generateSentStatus(cmp, '_emailMessagesAdvisor');
                                                                                hlp.setNewEmailCount(cmp);

                                                                                //---------------------------ACTION 8 START---------------------------------
                                                                                var action8 = cmp.get("c.GetEmailSummaryByCaseID");
                                                                                action8.setParams({
                                                                                    caseID: cmp.get('v.recordId'),
                                                                                    mode: 'Negotiator'
                                                                                });
                                                                                action8.setCallback(hlp, function (response8) {
                                                                                    var state = response8.getState();
                                                                                    if (state === "SUCCESS") {
                                                                                        try {
                                                                                            var emailMessages = response8.getReturnValue();
                                                                                            cmp.set("v._emailMessagesNegotiator", emailMessages);
                                                                                            hlp.generateSentStatus(cmp, '_emailMessagesNegotiator');
                                                                                            hlp.setNewEmailCount(cmp);


                                                                                            //---------------------------ACTION 9 START---------------------------------
                                                                                            var action9 = cmp.get("c.GetPatientBillTotal");
                                                                                            action9.setParams({
                                                                                                caseId: cmp.get('v.recordId')
                                                                                            });
                                                                                            action9.setCallback(hlp, function (response9) {
                                                                                                var state = response9.getState();
                                                                                                if (state === "SUCCESS") {
                                                                                                    try {
                                                                                                        var _patientBill = response9.getReturnValue();
                                                                                                        cmp.set("v._patientBill", _patientBill);
                                                                                                        cmp.set('v.initialized', true);
                                                                                                        cmp.set('v.showSpinner', false);
                                                                                                    } catch (err) {
                                                                                                        console.error(err);
                                                                                                        hlp.handleErrors(err.message);
                                                                                                    }
                                                                                                } else if (state === "ERROR") {
                                                                                                    console.error(response9.getError());
                                                                                                    this.handleErrors(response9.getError());
                                                                                                }
                                                                                            });
                                                                                            $A.enqueueAction(action9);
                                                                                            //---------------------------ACTION 9 END---------------------------------

                                                                                            //if we've reached this point then we're good to go, lets enable the gui for use
                                                                                            cmp.set('v.initialized', true);
                                                                                            hlp.selectCaseDetails(cmp);
                                                                                            hlp.subscribeEmailIn(cmp);
                                                                                            cmp.set('v.showSpinner', false);
                                                                                        } catch (err) {
                                                                                            console.error(err);
                                                                                            hlp.handleErrors(err.message);

                                                                                        }
                                                                                    } else if (state === "ERROR") {
                                                                                        console.error(response8.getError());
                                                                                        this.handleErrors(response8.getError());
                                                                                    }
                                                                                });
                                                                                $A.enqueueAction(action8);
                                                                                //---------------------------ACTION 8 END---------------------------------

                                                                            } catch (err) {
                                                                                console.error(err);
                                                                                hlp.handleErrors(err.message);
                                                                            }
                                                                        } else if (state === "ERROR") {
                                                                            console.error(response7.getError());
                                                                            this.handleErrors(response7.getError());
                                                                        }
                                                                    });
                                                                    $A.enqueueAction(action7);
                                                                    //---------------------------ACTION 7 END---------------------------------

                                                                } else if (state === "ERROR") {
                                                                    console.error(response6.getError());
                                                                    hlp.handleErrors(response6.getError());
                                                                }
                                                            });
                                                            $A.enqueueAction(action6);
                                                            //---------------------------ACTION 6 END---------------------------------

                                                        } else if (state === "ERROR") {
                                                            console.error(response5.getError());
                                                            this.handleErrors(response5.getError());
                                                        }
                                                    });
                                                    $A.enqueueAction(action5);
                                                    //---------------------------ACTION 5 END---------------------------------

                                                } else if (state === "ERROR") {
                                                    console.error(response4.getError());
                                                    hlp.handleErrors(response4.getError());
                                                }

                                            });
                                            $A.enqueueAction(action4);
                                            //---------------------------ACTION 4 END---------------------------------
                                        } else if (state === "ERROR") {
                                            console.error(response3B.getError());
                                            hlp.handleErrors(response3B.getError());
                                        }
                                    });
                                    $A.enqueueAction(action3B);
                                    //---------------------------ACTION 3B END---------------------------------                                    
                                } else if (state === "ERROR") {
                                    console.error(response3.getError());
                                    hlp.handleErrors(response3.getError());
                                }
                            });
                            $A.enqueueAction(action3);
                            //---------------------------ACTION 3 END---------------------------------

                        } else if (state === "ERROR") {
                            console.error(response2.getError());
                            hlp.handleErrors(response2.getError());
                        }
                    });
                    $A.enqueueAction(action2);
                    //---------------------------ACTION 2 END---------------------------------
                } else if (state === "ERROR") {
                    console.error(response.getError());
                    hlp.handleErrors(response.getError());
                }
            });
            $A.enqueueAction(action1);
            //---------------------------ACTION 1 END---------------------------------
        } catch (err) {
            console.error(err);
            hlp.handleErrors(err.message, cmp);

        }
    },

    reCalc: function (cmp) {
        var hlp = this;
        try {
            var _patientBill = cmp.get('v._patientBill');
            var _caseOriginalClaims = cmp.get('v._caseOriginalClaims');

            //NOTE: patientBill used to be a list to accomodate a list of patient bills to be entered, we changed it to only allow a single line for now.
            if (_patientBill) {
                //_patientBill.forEach(function (itm) {
                _patientBill.Remaining_Cost_Share_Balance__c = 0.00;
                _patientBill.Actual_Balance_Bill_Amount__c = 0.00;
                _patientBill.Cost_Share_Overpayment__c = 0.00;



                if (!_patientBill.Patient_Paid_Amount__c) {
                    _patientBill.Patient_Paid_Amount__c = 0.00;
                }

                if (_caseOriginalClaims && Array.isArray(_caseOriginalClaims)) {
                    _caseOriginalClaims.forEach(function (coc) {
                        if (coc.Claim_Number__c == 'Total Case') {
                            if (coc.Cost_Share__c && coc.Cost_Share__c > 0) {
                                _patientBill.Cost_Share_Overpayment__c = _patientBill.Patient_Paid_Amount__c - coc.Cost_Share__c;
                            } else {
                                _patientBill.Cost_Share_Overpayment__c = _patientBill.Patient_Paid_Amount__c;
                            }

                            if (coc.Cost_Share__c) {
                                _patientBill.Remaining_Cost_Share_Balance__c = coc.Cost_Share__c - _patientBill.Patient_Paid_Amount__c;

                                if (_patientBill.Remaining_Cost_Share_Balance__c < 0) {
                                    _patientBill.Remaining_Cost_Share_Balance__c = 0.00;
                                }
                            }
                        }
                    });
                }

                //_patientBill.Actual_Balance_Bill_Amount__c = _patientBill.Patient_Paid_Amount__c - _patientBill.Remaining_Cost_Share_Balance__c;
                _patientBill.Actual_Balance_Bill_Amount__c = _patientBill.Patient_Total_Bill_Amount__c - _patientBill.Remaining_Cost_Share_Balance__c + parseFloat(_patientBill.Cost_Share_Overpayment__c);

                if (_patientBill.Actual_Balance_Bill_Amount__c < 0) {
                    _patientBill.Actual_Balance_Bill_Amount__c = 0.00;
                }
                //});

                cmp.set('v._patientBill', _patientBill);
            }

        } catch (err) {
            console.error(err);
            hlp.handleErrors(err, cmp);
        }
    },


    moveStatusIfNeeded: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.MoveStatusIfNeeded");
            action.setParams({
                caseId: cmp.get('v._caseDetail').Id,
                selectedTab: cmp.get('v._selectedTab')
            });

            action.setCallback(hlp, function (response) {

                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        cmp.set('v._caseDetail', response.getReturnValue());
                        hlp.checkForQueuedTasks(cmp);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    hlp.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    checkForQueuedTasks: function (cmp) {
        var hlp = this;

        try {

            var action = cmp.get("c.GetTasksQueuedForCreation");
            action.setParams({
                caseId: cmp.get('v.recordId')
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        var tasksCreated = response.getReturnValue();
                        if (tasksCreated.length > 0) {
                            var openTasks = [];
                            var integrationTasks = [];
                            tasksCreated.forEach(function (itm) {
                                if (itm.Integration_Task__r && itm.Spit_Executed__c == false && itm.Automation_Type__c == 'Auto') {
                                    integrationTasks.push(itm);
                                } else if (itm.Automation_Type__c == 'User') {
                                    openTasks.push(itm);
                                }
                            });
                            var appEvent = $A.get("e.c:evtNewTask");
                            appEvent.fire();

                            if (openTasks.length > 0) {

                                hlp.handleWarning('New Open Tasks', 'Newly created Tasks are pending.  Please review and submit when ready.');
                            }

                            if (integrationTasks.length > 0) {
                                hlp.handleWarning('Executing Automation Tasks.', 'Processing Tasks...please wait for them to complete.');
                                cmp.set('v.showSpinner', true);
                                hlp.executeSPIT(cmp, integrationTasks[0], integrationTasks);
                            }
                        }
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    hlp.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            console.error(err);
            hlp.handleErrors(err);
        }
    },

    executeSPIT: function (cmp, qTask, integrationTasks) {
        var hlp = this;
        try {
            cmp.set('v.showSpinner', true);
            if (cmp.get('v._trainingMode') === false) {
                cmp.set('v.spitterPageRef', this.getExternalConfigValue(cmp, 'SPIT Endpoint') + '?id=' + qTask.Integration_Task__c + '&token=' + qTask.Integration_Task__r.Encrypted_GUID__c);
            }

            //now lets poll the SPIT table until our SPIT task is completed, OR we execeed the maximum allowed wait period
            var pollId = window.setInterval(
                $A.getCallback(function () {
                    hlp.getSPITstatus(cmp, qTask, pollId, integrationTasks);
                }), hlp.getExternalConfigValue(cmp, 'SPIT Polling Interval')
            );
            cmp.set('v.pollId', pollId);
        } catch (err) {
            var catchPolId = cmp.get('v.pollId');
            if (catchPolId) {
                cmp.set('v.pollId', '');
                window.clearInterval(catchPolId);
                cmp.set('v.showSpinner', false);
            }

            hlp.updateTaskQueueSpitStatusAsExecuted(cmp, qTask.Id, true);

            console.error(err);
            this.handleErrors(err);
        }
    },

    updateTaskQueueSpitStatusAsExecuted: function (cmp, qTaskId, errorEncountered) {
        try {
            var action2 = cmp.get("c.UpdateTaskQueueSpitStatusAsExecuted");
            action2.setParams({
                taskQueueId: qTaskId,
                errorEncountered: errorEncountered
            });

            action2.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "ERROR") {
                    this.handleErrors(response.getError());
                }
            });
            $A.enqueueAction(action2);
        } catch (err) {
            console.error(err);
        }
    },

    getSPITstatus: function (cmp, qTask, pollId, integrationTasks) {
        var hlp = this;
        var spitRecord;

        try {
            var action = cmp.get("c.GetSPITRecord");
            action.setParams({
                id: qTask.Integration_Task__r.Id
            });

            action.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    spitRecord = response.getReturnValue();
                    if (spitRecord.Status__c == 'COMPLETE') {
                        var appEvent = $A.get("e.c:evtNewTask");
                        appEvent.fire();

                        //SPITTER IS DONE
                        //CLEAR OUR COUNTERS SO WE NO LONGER POLL
                        cmp.set('v.accumulatedPollTime', 0);
                        window.clearInterval(pollId);
                        cmp.set('v.pollId', '');
                        cmp.set('v.showSpinner', false);
                        var errorEncountered = false;
                        qTask.Spit_Executed__c = true;
                        cmp.set('v.showSpinner', false);

                        if (spitRecord.Disposition__c != 'SUCCESS') {
                            errorEncountered = true;
                        }

                        hlp.updateTaskQueueSpitStatusAsExecuted(cmp, qTask.Id, errorEncountered);

                        if (spitRecord.Disposition__c != 'SUCCESS') {
                            hlp.handleWarning('Failed to Execute Task', spitRecord.Message__c);
                        } else {
                            integrationTasks.forEach(function (itm) {
                                if (itm.Id == qTask.Id) {
                                    itm.Spit_Executed__c = true;
                                } else if (itm.Spit_Executed__c == false) {
                                    hlp.executeSPIT(cmp, itm, integrationTasks);
                                }
                            });
                        }
                    } else {
                        //NO RESULT FROM SPITTER YET SO LETS GET READY TO RUN AGAIN
                        var maxPollTime = parseInt(hlp.getExternalConfigValue(cmp, 'SPIT MAX Poll Time'), 10);
                        var accumPollTime = parseInt(cmp.get('v.accumulatedPollTime'), 10);
                        accumPollTime = accumPollTime + parseInt(hlp.getExternalConfigValue(cmp, 'SPIT Polling Interval'), 10);

                        if (accumPollTime >= maxPollTime) {
                            window.clearInterval(pollId);
                            cmp.set('v.pollId', '');
                            cmp.set('v.accumulatedPollTime', 0);
                            cmp.set('v.showSpinner', false);
                            hlp.handleWarning("Transaction did not complete", "You can try executing the Task manually, or contact support.");
                            hlp.updateTaskQueueSpitStatusAsExecuted(cmp, qTask.Id, true);
                        } else {
                            cmp.set('v.accumulatedPollTime', accumPollTime);
                        }
                    }
                } else if (state === "ERROR") {
                    hlp.handleErrors(response.getError());
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            window.clearInterval(pollId);
            if (cmp) {
                cmp.set('v.pollId', '');
                cmp.set('v.accumulatedPollTime', 0);
                cmp.set('v.showSpinner', false);
                hlp.handleErrors(err.message);
            }
        }
    },

    getNegotiationPrep: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.GetNegotiationPrep");
            action.setParams({
                caseId: cmp.get('v.recordId'),
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        var _negotiationPrep = response.getReturnValue();
                        cmp.set("v._negotiationPrep", _negotiationPrep);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    this.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },


    getEngagement: function (cmp) {
        var hlp = this;

        try {
            var action = cmp.get("c.GetEngagement");
            action.setParams({
                caseId: cmp.get('v.recordId'),
            });

            action.setCallback(hlp, function (response) {
                cmp.set('v.showSpinner', false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    try {
                        var _engagement = response.getReturnValue();
                        cmp.set("v._engagement", _engagement);
                    } catch (err) {
                        hlp.handleErrors(err.message, cmp);
                        console.error(err);
                    }
                } else if (state === "ERROR") {
                    this.handleErrors(response.getError(), cmp);
                }
            });
            $A.enqueueAction(action);
        } catch (err) {
            hlp.handleErrors(err.message, cmp);
            console.error(err);
        }
    },

    getExternalConfigValue: function (cmp, configName) {
        var returnValue;

        var externalConfigs = cmp.get('v._externalConfigs');

        externalConfigs.forEach(function (config) {
            if (config.Name == configName) {
                returnValue = config.ConfigValue__c;
            }
        });

        return returnValue;
    },

    selectCaseDetails: function (cmp) {
        var helper = this;
        var sPageURL = decodeURIComponent(window.location.search.substring(1)); 
        var sURLVariables = sPageURL.split('&'); 
        var sParameterName;
        var i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('='); 
        }
        if(sParameterName && sParameterName.length>1){
            if(sParameterName[1] === 'chatter' && cmp.get("v.isNavigatedToChatter") === false ) {
                helper.selectChatter(cmp);
                cmp.set("v.isNavigatedToChatter",true);
            } else {
                cmp.set('v._selectedTab', 'Case Details');
                cmp.set('v.showMilestoneComments', true);
                cmp.set('v.showOpenTasks', true);
                cmp.set('v.showCaseProgressLog', true);
                cmp.set('v.showCaseMetrics', true);
            }
        } else {
            cmp.set('v._selectedTab', 'Case Details');
            cmp.set('v.showMilestoneComments', true);
            cmp.set('v.showOpenTasks', true);
            cmp.set('v.showCaseProgressLog', true);
            cmp.set('v.showCaseMetrics', true);
        }
        /*cmp.set('v._selectedTab', 'Case Details');
        cmp.set('v.showMilestoneComments', true);
        cmp.set('v.showOpenTasks', true);
        cmp.set('v.showCaseProgressLog', true);
        cmp.set('v.showCaseMetrics', true);*/

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

        this.moveStatusIfNeeded(cmp);

    },

    selectEngagement: function (cmp) {
        cmp.set('v._selectedTab', 'Engagement');

        cmp.set('v.showMilestoneComments', true);
        cmp.set('v.showOpenTasks', true);
        cmp.set('v.showCaseProgressLog', true);
        cmp.set('v.showCaseMetrics', true);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

    },

    selectChatter: function (cmp) {
        //$A.get("e.force:refreshView").fire();

        cmp.set('v._selectedTab', 'Chatter');
        cmp.set('v.showMilestoneComments', false);
        cmp.set('v.showOpenTasks', false);
        cmp.set('v.showCaseProgressLog', false);
        cmp.set('v.showCaseMetrics', false);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();


    },

    selectNegotiationPrep: function (cmp) {
        cmp.set('v._selectedTab', 'Negotiation Prep');
        cmp.set('v.showMilestoneComments', true);
        cmp.set('v.showOpenTasks', true);
        cmp.set('v.showCaseProgressLog', true);
        cmp.set('v.showCaseMetrics', true);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

        this.moveStatusIfNeeded(cmp);


    },

    selectNegotiationResults: function (cmp) {
        cmp.set('v._selectedTab', 'Negotiation Results');
        cmp.set('v.showMilestoneComments', true);
        cmp.set('v.showOpenTasks', true);
        cmp.set('v.showCaseProgressLog', true);
        cmp.set('v.showCaseMetrics', true);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

        this.moveStatusIfNeeded(cmp);

    },

    selectFollowUp: function (cmp) {
        cmp.set('v._selectedTab', 'Follow Up');
        cmp.set('v.showMilestoneComments', true);
        cmp.set('v.showOpenTasks', true);
        cmp.set('v.showCaseProgressLog', true);
        cmp.set('v.showCaseMetrics', true);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

        this.moveStatusIfNeeded(cmp);

    },

    selectComplete: function (cmp) {
        cmp.set('v._selectedTab', 'Complete');
        cmp.set('v.showMilestoneComments', false);
        cmp.set('v.showOpenTasks', false);
        cmp.set('v.showCaseProgressLog', true);
        cmp.set('v.showCaseMetrics', true);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

        this.checkForQueuedTasks(cmp);


    },

    selectFiles: function (cmp) {
        cmp.set('v._selectedTab', 'Files');
        cmp.set('v.showMilestoneComments', false);
        cmp.set('v.showOpenTasks', false);
        cmp.set('v.showCaseProgressLog', false);
        cmp.set('v.showCaseMetrics', false);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();


    },

    selectTasks: function (cmp, helper) {
        cmp.set('v._selectedTab', 'Tasks');
        cmp.set('v.showMilestoneComments', false);
        cmp.set('v.showOpenTasks', false);
        cmp.set('v.showCaseProgressLog', false);
        cmp.set('v.showCaseMetrics', false);
        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();

    },

    selectComments: function (cmp) {
        cmp.set('v._selectedTab', 'Comments');
        cmp.set('v.showMilestoneComments', false);
        cmp.set('v.showOpenTasks', false);
        cmp.set('v.showCaseProgressLog', false);
        cmp.set('v.showCaseMetrics', false);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();


    },

    selectCommunications: function (cmp) {
        cmp.set('v._selectedTab', 'Communications');
        cmp.set('v.showMilestoneComments', false);
        cmp.set('v.showOpenTasks', false);
        cmp.set('v.showCaseProgressLog', false);
        cmp.set('v.showCaseMetrics', false);

        var appEvent = $A.get("e.c:V2_evtTabChanged");
        appEvent.fire();


    },

    subscribe: function (cmp) {
        // Get the empApi component.
        var empApi = cmp.find("empApi");
        empApi.setDebugFlag(true);
        var hlpr = this;

        // Callback function to be passed in the subscribe call.
        // After an event is received, this callback prints the event
        // payload to the console.
        var callback = function (message) {
            var _docusign = cmp.get('v._docusign');
            var docusignArtifact = message.data.sobject;
            var isUpdate = false;

            _docusign.forEach(function (itm) {
                if (itm.Id == docusignArtifact.Id) {
                    isUpdate = true;
                    itm.CDocuSign_Envelope__c.Envelope_Status__c = docusignArtifact.Envelope_Status__c;
                }
            });

            if (!isUpdate) {
                _docusign.push(docusignArtifact);
            }

            cmp.set("v._docusign", _docusign);
        }.bind(this);

        // Error handler function that prints the error to the console.
        var errorHandler = function (message) {
            hlpr.handleErrors(message);
        }.bind(this);

        // Register error listener and pass in the error handler function.
        empApi.onError(errorHandler);

        var sub;
        // Subscribe to the channel and save the returned subscription object.
        empApi.subscribe("/topic/DocuSign_Inbound_Message?Related_Case__c=" + cmp.get('v.recordId'), -1, callback).then(function (value) {



            cmp.set('v.subscription', value);
        });
    },


    subscribeEmailIn: function (cmp) {
        // Get the empApi component.
        var empApi = cmp.find("empApi");
        empApi.setDebugFlag(true);
        var hlpr = this;

        // Callback function to be passed in the subscribe call.
        // After an event is received, this callback prints the event
        // payload to the console.
        var callback = function (message) {
            this.getNewEmailMessageForCase(cmp, message.data.sobject.Case__c, message.data.sobject.Id);
        }.bind(this);

        empApi.isEmpEnabled().then(function (enabled) {
            if (!enabled) {
                hlpr.handleWarning('Email Refresh Disabled', 'Emails will need to be manually refreshed.');
                return;
            } else {
                // Error handler function that prints the error to the console.
                var errorHandler = function (message) {
                    console.error(message);
                    hlpr.handleWarning('Email Refresh Disabled', 'Emails will need to be manually refreshed.');
                }.bind(this);

                // Register error listener and pass in the error handler function.
                empApi.onError(errorHandler);

                var sub;
                // Subscribe to the channel and save the returned subscription object.
                setTimeout(function () {
                    empApi.subscribe("/topic/EmailInboundRecieved", -1, callback).then(function (value) {
                        cmp.set('v.subscription', value);
                    });
                }, 500);
            }
        });
    },

    // subscribeEmailIn: function (cmp) {
    //     // Get the empApi component.
    //     var empApi = cmp.find("empApi");
    //     empApi.setDebugFlag(true);
    //     var hlpr = this;

    //     // Callback function to be passed in the subscribe call.
    //     // After an event is received, this callback prints the event
    //     // payload to the console.
    //     var callback = function (message) {
    //         this.getNewEmailMessageForCase(cmp, message.data.sobject.Case__c, message.data.sobject.Id);
    //     }.bind(this);

    //     // Error handler function that prints the error to the console.
    //     var errorHandler = function (message) {
    //         console.error(message);
    //         hlpr.handleWarning('Email Refresh Disabled', 'Emails will need to be manually refreshed.');
    //     }.bind(this);

    //     // Register error listener and pass in the error handler function.
    //     empApi.onError(errorHandler);

    //     var sub;
    //     // Subscribe to the channel and save the returned subscription object.
    //     empApi.subscribe("/topic/EmailInboundRecieved", -1, callback).then(function (value) {
    //         cmp.set('v.subscription', value);
    //     });
    // },

    // subscribeEmailInVersion2: function (cmp) {
    //     var hlp = this;

    //     //check for existing subscriptions for this user
    //     var action1 = cmp.get("c.GetEmailSubscriptionsForUser");
    //     action1.setCallback(hlp, function (response) {
    //         var state = response.getState();
    //         if (state === "SUCCESS") {
    //             try {
    //                 var subscriptions = response.getReturnValue();
    //                 if (subscriptions) {
    //                     subscriptions.forEach(function (itm) {
    //                         var unsubscription = {
    //                             id: itm.Subscription_Id__c,
    //                             channel: itm.Subscription_Channel__c,
    //                             replayId: itm.Subscription_Replay_Id__c
    //                         };
    //                         try {
    //                             $A.getCallback(function () {
    //                                 hlp.unsubscribe(cmp, itm.Id, unsubscription);
    //                             })();


    //                         } catch (err) {
    //                             console.error(err);
    //                         }
    //                     });
    //                 }

    //                 //NOW WE are ready to do our subscribe call
    //                 var empApi = cmp.find("empApi");
    //                 empApi.setDebugFlag(true);
    //                 var hlpr = this;

    //                 // Callback function to be passed in the subscribe call.
    //                 // After an event is received, this callback prints the event
    //                 // payload to the console.
    //                 var callback = function (message) {
    //                     this.getNewEmailMessageForCase(cmp, message.data.sobject.Id);
    //                 }.bind(this);

    //                 // Error handler function that prints the error to the console.
    //                 var errorHandler = function (message) {
    //                     hlpr.handleErrors(message);
    //                 }.bind(this);

    //                 // Register error listener and pass in the error handler function.
    //                 empApi.onError(errorHandler);

    //                 var sub;
    //                 // Subscribe to the channel and save the returned subscription object.
    //                 empApi.subscribe("/topic/EmailInboundRecieved?Case__c=" + cmp.get('v.recordId'), -1, callback).then(function (value) {
    //                     var actionSaveSub = cmp.get("c.StoreEmailSubscription");
    //                     actionSaveSub.setParams({
    //                         caseId: cmp.get('v.recordId'),
    //                         subscriptionId: value.id,
    //                         subscriptionChannel: value.channel,
    //                         subscriptionReplayId: value.replayId
    //                     });
    //                     actionSaveSub.setCallback(hlp, function (response) {
    //                         if (state === "ERROR") {
    //                             console.error(err);
    //                             hlp.handleErrors(err.message);
    //                         }
    //                     });
    //                     $A.enqueueAction(actionSaveSub);
    //                 });
    //             } catch (err) {
    //                 console.error(err);
    //                 hlp.handleErrors(err.message);

    //             }
    //         } else if (state === "ERROR") {
    //             console.error(response.getError());
    //             this.handleErrors(response.getError());
    //         }
    //     });
    //     $A.enqueueAction(action1);
    // },

    // // Client-side function that invokes the unsubscribe method on the
    // // empApi component.
    // unsubscribe: function (cmp, subId, subscription) {
    //     var hlp = this;

    //     try {
    //         // Get the empApi component.
    //         var empApi = cmp.find("empApi");

    //         if (subscription) {
    //             // Callback function to be passed in the subscribe call.
    //             var callback = function (message) {
    //                 var action = cmp.get("c.DeleteEmailSubscription");
    //                 action.setParams({
    //                     subId: subId
    //                 });
    //                 action.setCallback(hlp, function (response) {
    //                     if (state === "ERROR") {
    //                         console.error(err);
    //                     }
    //                 });
    //                 $A.enqueueAction(action);
    //             }.bind(this);

    //             // Error handler function that prints the error to the console.
    //             var errorHandler = function (message) {
    //                 console.error(message);
    //             }.bind(this);

    //             // Register error listener and pass in the error handler function.
    //             empApi.onError(errorHandler);

    //             // Unsubscribe from the channel using the sub object.
    //             empApi.unsubscribe(subscription, callback);
    //         }
    //     } catch (err) {
    //         this.handleErrors(err.message);
    //         console.error(err);
    //     }
    // },

    setNewEmailCount: function (cmp) {
        var hlp = this;
        try {
            var includeAdvisor = false;
            var includeNegotiator = false;
            var _profile = cmp.get('v._profile');

            if (_profile.Name == 'Advisor User') {
                includeAdvisor = true;
                includeNegotiator = false;
            } else if (_profile.Name == 'Negotiator User' || _profile.Name == 'Liaison Specialist User') {
                includeAdvisor = false;
                includeNegotiator = true;
            } else if (_profile.Name == 'OPS Manager' ||
                _profile.Name == 'System Administrator') {
                includeAdvisor = true;
                includeNegotiator = true;
            }

            var _newEmailCount = 0;

            if (includeAdvisor) {
                cmp.get('v._emailMessagesAdvisor').forEach(function (itm) {
                    if (!itm.Last_Viewed_By__c && itm.Email_Direction__c == 'Inbound') {
                        _newEmailCount++;
                    }
                });
            }

            if (includeNegotiator) {
                cmp.get('v._emailMessagesNegotiator').forEach(function (itm) {
                    if (!itm.Last_Viewed_By__c && itm.Email_Direction__c == 'Inbound') {
                        _newEmailCount++;
                    }
                });
            }

            cmp.set('v._newEmailCount', _newEmailCount);
        } catch (err) {
            console.error(err);
            hlp.handleErrors(err.message);
        }
    },

    getNewEmailMessageForCase: function (cmp, caseId, messageId) {
        var hlp = this;
        try {

            if (caseId == cmp.get('v.recordId')) {
                var messageType = '';
                var action = cmp.get("c.GetEmailSummaryByMessageId");
                action.setParams({
                    messageId: messageId
                });

                action.setCallback(hlp, function (response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        try {
                            var emailMessage = response.getReturnValue();

                            if (emailMessage && emailMessage.Email_Mode__c.toUpperCase() == "ADVISOR") {
                                messageType = '_emailMessagesAdvisor';
                            } else {
                                messageType = '_emailMessagesNegotiator';
                            }
                            var _emailMessages = cmp.get('v.' + messageType);
                            _emailMessages.unshift(emailMessage)
                            cmp.set('v.' + messageType, _emailMessages);
                            hlp.generateSentStatus(cmp, messageType);
                            hlp.setNewEmailCount(cmp);
                        } catch (err) {
                            hlp.handleErrors(err.message);
                            console.error(err);
                        }
                    } else if (state === "ERROR") {
                        this.handleErrors(response.getError());
                    }
                });
                $A.getCallback(function () {
                    $A.enqueueAction(action);
                })();
            }
        } catch (err) {
            console.error(err);
            hlp.handleErrors(err.message);
        }
    },

    generateSentStatus: function (cmp, messageType) {
        try {
            var _emailMessages = cmp.get("v." + messageType);

            if (_emailMessages && Array.isArray(_emailMessages)) {

                var line1Text = '';

                _emailMessages.forEach(function (itm) {
                    var status = [];
                    if (itm.Email_Direction__c == 'Inbound') {
                        if (itm.Digital_Inbound__c == true) {
                            line1Text = 'Received from Patient Portal';
                        } else {
                            line1Text = 'Received';
                        }
                    } else {
                        line1Text = (itm.Sent__c === true ? 'Sent' : 'Not Sent');
                    }
                    if (itm.Secure_Email_Read__c === true) {
                        line1Text = '';
                        status.push('Sent with Secure Messaging');
                    }
                    if (itm.Secure_Email__c === true) {
                        line1Text = '';
                        status.push('Sent with Secure Messaging');
                    }

                    if (!itm.Sender_Contact__c && itm.Email_Direction__c == 'Inbound') {
                        status.push('No Case Contact found for this Email Address</lic>');
                    }

                    if (itm.Blocked__c === true) {
                        line1Text = '';
                        status.push('BLOCKED - PII/PHI - Violation');
                    }
                    if (itm.Undeliverable__c === true) {
                        line1Text = '';
                        status.push('Undeliverable - Failed to Send');
                    }

                    if (line1Text) {
                        if (status.length > 0) {
                            itm.status = line1Text + '\r\n' + '<ul><li>' + status.join("</li><li>");
                        } else {
                            itm.status = line1Text;
                        }
                    } else {
                        if (status.length <= 1) {
                            itm.status = status[0];
                        } else {
                            itm.status = '<ul><li>' + status.join("</li><li>");
                        }
                    }
                });
            }
        } catch (err) {
            console.error(err);
            this.handleErrors(err, cmp);
        }
    },

    setTrainingModeIfNeeded: function (cmp) {
        try {
            if (cmp.get('v.trainingModeChecked') === false) {
                if (this.getExternalConfigValue(cmp, 'TRAINING MODE') == 'ON') {
                    cmp.set('v._trainingMode', true);
                } else {
                    cmp.set('v._trainingMode', false);
                }
                cmp.set('v.trainingModeChecked', true);
            }
        } catch (err) {
            this.handleErrors(cmp, err);
        }
    },

    handleWarning: function (title, message) {
        let toastParams = {
            title: title,
            message: "Unknown error", // Default error message
            type: "warning",
            mode: 'dismissable',
            druation: 2000
        };

        if (message) {
            toastParams.message = message;
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },


    handleErrors: function (errors, cmp) {
        // Configure error toast
        let toastParams = {
            mode: 'sticky',
            title: "Error",
            message: "Unknown error", // Default error message
            type: "error",

        };

        if (errors) {
            if (Array.isArray(errors) && errors.length > 0) {
                if (errors[0].message) {
                    toastParams.message = errors[0].message;
                } else if (errors[0].fieldErrors) {
                    toastParams.message = this.objToString(errors[0].fieldErrors);
                } else {
                    toastParams.message = 'Could not execute requested action';
                }
            } else {
                toastParams.message = 'Could not execute requested action';
            }
        } else {
            toastParams.message = 'Could not execute requested action';
        }

        if (cmp) {
            cmp.set('v.showSpinner', false);
        }

        // Fire error toast
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams(toastParams);
        toastEvent.fire();
    },

    objToString: function (obj) {
        var str = '';
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str += p + '::' + obj[p] + '\n';
            }
        }
        return str;
    },

    apex: function (cmp, apexAction, params) {
        var p = new Promise($A.getCallback(function (resolve, reject) {
            var action = cmp.get("c." + apexAction + "");
            action.setParams(params);
            action.setCallback(this, function (callbackResult) {
                if (callbackResult.getState() == 'SUCCESS') {
                    resolve(callbackResult.getReturnValue());
                } else if (callbackResult.getState() == 'ERROR') {
                    console.log('ERROR', callbackResult.getError());
                    reject(callbackResult.getError());
                }
            });
            $A.enqueueAction(action);
        }));
        return p;
    }
})